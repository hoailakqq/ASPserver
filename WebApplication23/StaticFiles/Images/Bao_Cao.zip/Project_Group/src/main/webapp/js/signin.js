$(document).ready(function() {

	// Sign in
	$("#nameRegis").focusout(function() {
		if ($("#nameRegis").val() == '') {
			alert('Bạn chưa nhập tên đăng nhập');
			return false;
		}
	});

	$("#passRegis").focusout(function() {
		if ($("#passRegis").val() == '') {
			alert('Bạn chưa nhập password');
			return false;
		}
	});

	$("#confirmPass").focusout(function() {
		if ($("#confirmPass").val() == '') {
			alert('Bạn chưa nhập lại passsword');
			return false;
		}
	});

	$("#mailRegis").focusout(function() {
		if ($("#mailRegis").val() == '') {
			alert('Bạn chưa nhập email');
			return false;
		}
	});

	$("#fullNameRegis").focusout(function() {
		if ($("#fullNameRegis").val() == '') {
			alert('Bạn chưa nhập Họ và tên');
			return false;
		}
	});

	$("#btnDK").click(function() {
		var nameRegis = $("#nameRegis").val();
		var passRegis = $("#passRegis").val();
		var mailRegis = $("#mailRegis").val();
		var fullNameRegis = $("#fullNameRegis").val();
		
		$.ajax({
			url : "/ktdangky",
			type : "POST",
			data : {
				userName : nameRegis,
				pass : passRegis,
				email : mailRegis,
				fullName : fullNameRegis
			},
			success : function(value) {
				if (value) {
					window.location.href = "http://localhost:8080/dangnhap";
					alert("Đăng ký thành công !!!");
				} else {
					alert("Sai thông tin đăng nhập !!!");
				}

			}
		});

	});
});
