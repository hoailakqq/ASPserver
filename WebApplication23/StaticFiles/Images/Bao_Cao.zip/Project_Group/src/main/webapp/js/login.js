$(document).ready(function() {
	$("#cot1").click(function() {
		alert("hello!!!");
	});
	// Login
	$("#btnDN").click(function() {
		var email = $("#username").val();
		var password = $("#password").val();
		alert(password);
		$.ajax({
			url : "/ktdangnhap",
			type : "POST",
			data : {
				userName : email,
				pass : password
			},
			success : function(value) {
				if (value == '0') {
					window.localStorage.setItem('username', email);
					window.location.href = "http://localhost:8080/";

					alert("Đăng nhập thành công !!!");
				}

				if (value == '1') {
					window.localStorage.setItem('username', email);
					window.location.href = "http://localhost:8080/admin";

					alert("Admin Đăng nhập thành công !!!");
				}

				if (value == '-1') {
					alert("Sai !!!");
				}

			}
		})

	});// function bntdk

	$("#btnDN").click(function() {
		var email = $("#username").val();

		$.ajax({
			url : "/getgiohang",
			type : "POST",
			data : {
				userKH : email
			},
			success : function(value) {
				alert(value);
				window.localStorage.setItem('PPMiniCart', value)
			},
			error : function() {
				alert("Lưu giỏ hàng k thành công !!!");
			}

		})

	});// function bntdk

	$("#yesFP").click(function() {
		var email = $("#username").val();

		$.ajax({
			url : "/sendEmail",
			type : "POST",
			data : {
				email : email,
			},
			success : function(value) {
				if (value) {

					alert("Đã gửi password về email của bạn !!!");
				} else {
					alert("Username không tồn tại !!!");
				}

			}
		})

	});

	$("#btnFP").click(function() {
		var updateButton = document.getElementById('btnFP');
		var favDialog = document.getElementById('favDialog');

		updateButton.addEventListener('click', function() {
			favDialog.showModal();
		});
	});

	$("#backFP").click(function Redirect() {
		window.location.href = "http://localhost:8080/index";
	});
})// document
