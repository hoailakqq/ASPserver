$(document).ready(function() {

	$("#btnGioHang").click(function() {
		var username = window.localStorage.getItem('username');
		var values = window.localStorage.getItem('PPMiniCart');

		$.ajax({
			url : "/giohang",
			type : "POST",
			data : {
				userKH : username,
				value : values
			},
			success : function() {

			},
			error : function() {
				alert("Lưu giỏ hàng k thành công !!!");
			}
		})

	});

	$("#thanhtoan").click(function() {
		var updateButton = document.getElementById('thanhtoan');
		var favDialog = document.getElementById('favDialog');

		updateButton.addEventListener('click', function() {
			favDialog.showModal();
		});
	});

	$("#yes").click(function Redirect() {
		window.location.href = "http://localhost:8080/product";
	});
});