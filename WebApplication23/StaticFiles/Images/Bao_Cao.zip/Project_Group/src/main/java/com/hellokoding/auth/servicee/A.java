//package com.hellokoding.auth.web;
//
//import java.util.List;
//
//import javax.persistence.EntityManager;
//import javax.persistence.PersistenceContext;
//import javax.transaction.Transactional;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.ui.ModelMap;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.ResponseBody;
//
//import com.hellokoding.auth.modell.Category;
//import com.hellokoding.auth.modell.Menu;
//import com.hellokoding.auth.modell.User;
//import com.hellokoding.auth.modell.User_Roles;
//import com.hellokoding.auth.servicee.CategoryService;
//import com.hellokoding.auth.servicee.MenuService;
//import com.hellokoding.auth.servicee.UserService;
//
//@Controller
//public class MainController {
//	@Autowired
//	MenuService menuService;
//	@Autowired
//	UserService userService;
//	@Autowired
//	CategoryService categoryService;
//
//	@RequestMapping(value = { "/", "/index" }, method = RequestMethod.GET)
//	public String welcome(Model model) {
//		try {
//			List<Menu> menus = menuService.findAll();
//			for (int i = 0; i < menus.size(); i++) {
//				System.out.println("log: " + menus.get( i).toString());
//				model.addAttribute("menus", menus);
//				List<Category> categorys = categoryService.findCategory(i);
//				System.out.println(menus.get(i).getName());
//				for (int j = 0; j < categorys.size(); j++) {
//					System.out.println("log: " + categorys.get(j).getName());
//					System.out.println(categorys.size());
//				}
//				System.out.println("category"+i);
//				model.addAttribute("categorys"+i, categorys);
//			}
//
//		} catch (Exception e) {
//			System.out.println(e);
//		}
//		return "index";
//	}
//	@RequestMapping(value = { "/ktdangnhap" }, method = RequestMethod.POST)
//	@ResponseBody
//	public String loginControl(String userName, String pass, ModelMap map) {
//		User getuser = userService.findByUsername(userName);
//		boolean kt = false;
//		if (getuser != null && getuser.getPass().equals(pass)) {
//
//			kt = true;
//		}
//		return kt + "";
//
//	}
//
//	@Autowired
//	private BCryptPasswordEncoder bCryptPasswordEncoder;
//	
//	@PersistenceContext
//    private EntityManager entityManager;
//	
//	@Transactional
//	public void insertWithQuery(User user) {
//						entityManager.createNativeQuery("INSERT INTO cdw1.`user`(username, pass, email, ho_ten, status, users_iduser, hoten) VALUES (?, ?, ?, ?, ?, ?, ?)")
//	      .setParameter(1, user.getUsername())
//	      .setParameter(2, user.getPass())
//	      .setParameter(3, user.getEmail())
//	      .setParameter(4, user.getHoTen())
//	      .setParameter(5, new User_Roles((long) 1, "normal"))
//	      .setParameter(6, true)
//	      .setParameter(7, user.getHoTen())
//	      .executeUpdate();
//	}
//	
//	//api nhập username để trả
//	
//	
//	@Transactional
//	@RequestMapping(value = { "/ktdangky" }, method = RequestMethod.POST)
//	@ResponseBody
//	public String RegisterControl(String userName, String pass, String email, String fullName, ModelMap map) {
//		
//		boolean kt = true;
//		User getuser = userService.findByUsername(userName);
//		System.out.println(getuser);
//		if (getuser != null) {
//			System.out.println("tao co phan tu");
//			kt = false;
//			return kt + "";
//		} else {
////			String passCrypt = bCryptPasswordEncoder.encode(pass);
//			User a = new User(userName, "", email, fullName, new User_Roles((long) 1, "normal"), true);
//			try {
//				System.out.println("tao van chay tiep");
//				insertWithQuery(a);
//			} catch (Exception e) {
//				// TODO: handle exception
//				return false+"";
//			}
//			return kt + "";
//		}
//		
//	}
////	@GetMapping("/dangky")
////	public String viewPersonList(Model model) {
////		model.addAttribute("user", new User());
////		return "login";
////	}
////
////	@PostMapping("/dangky")
////	public String dangKyForm(@Valid @ModelAttribute("user") User user, BindingResult bindingResult, Model model) {
////		if (bindingResult.hasErrors()) {
////			System.out.println("user2");
////			return "login";
////		} else {
////			System.out.println("user3");
////			return "dangky_thanhcong";
////		}
////	}
//}
//
////<div class="form">
////<h2>Login to your account</h2>
////							
////
////
////</div>
////<div class="form">
////<h2>Login to your account</h2>
//
////</div>
////<form:form action="/dangky" method="post" modelAttribute="user">
////<form:input path="hoTen" name="Username" placeholder="Username"
////	required=" "/>
////	<form:input type="password" name="Password"
////		placeholder="Password" required=" " path="matKhau"/>
////		<form:button >Đăng nhập</form:button>
////</form:form>
//
//
//Kết thúc cuộc trò chuyện
//Nhập ti