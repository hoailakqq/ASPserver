package com.hellokoding.auth.servicee;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaBuilder;

import org.hibernate.Session;
//import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.hellokoding.auth.modell.Menu;
import com.hellokoding.auth.modell.Product;
import com.hellokoding.auth.modell.User_Roles;
import com.hellokoding.auth.repositoryy.MenuRepository;
import com.hellokoding.auth.repositoryy.ProductRepository;
import com.hellokoding.auth.repositoryy.UserRepository;

@Repository
@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ProductServiceImpl implements ProductService {

//	SessionFactory sessionFactory;
	@Autowired
	@PersistenceContext
	private EntityManager entityManager;

	@Autowired
	private ProductRepository productRepository;
	@Autowired
	private MenuRepository menuRepository;

	@SuppressWarnings("unchecked")
	@Transactional
	public List<Product> dtNoiBat() {
//		EntityManager em = null;
		// Session session = sessionFactory.getCurrentSession();
//		CriteriaBuilder cb = em.getCriteriaBuilder();
//		liSanPhams = (List<Product>) em.createQuery("from Product oder by date desc").setMaxResults(10).getResultList();
		List<Product> liSanPhams = new ArrayList<Product>();
		liSanPhams = entityManager
				.createQuery("select p from Product p where" + " idmenu = 0 and status =1 ORDER BY p.date DESC ")
				.setMaxResults(4).getResultList();
		return liSanPhams;

	}

	@SuppressWarnings("unchecked")
	@Transactional
	public List<Product> ltNoiBat() {
		List<Product> liSanPhams = new ArrayList<Product>();
		liSanPhams = entityManager
				.createQuery("select p from Product p where" + " idmenu = 2 and status =1 ORDER BY p.date DESC ")
				.setMaxResults(4).getResultList();
		return liSanPhams;

	}

	@SuppressWarnings("unchecked")
	@Transactional
	public List<Product> pkNoiBat() {
		List<Product> liSanPhams = new ArrayList<Product>();
		liSanPhams = entityManager
				.createQuery("select p from Product p where" + " idmenu = 4 and status =1 ORDER BY p.date DESC ")
				.setMaxResults(4).getResultList();
		return liSanPhams;
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public List<Product> tbNoiBat() {
		List<Product> liSanPhams = new ArrayList<Product>();
		liSanPhams = entityManager
				.createQuery("select p from Product p where" + " idmenu = 3 and status =1 ORDER BY p.date DESC ")
				.setMaxResults(4).getResultList();
		return liSanPhams;

	}

	@SuppressWarnings("unchecked")
	@Transactional
	public List<Product> bestSeller() {
		List<Product> liSanPhams = new ArrayList<Product>();
		liSanPhams = entityManager
				.createQuery("select p from Product p where status = 1  ORDER BY (so_luong_nhap-so_luong_con) desc")
				.setMaxResults(20).getResultList();
		return liSanPhams;

	}

	@SuppressWarnings("unchecked")
	@Transactional
	public List<Product> bestnew() {
		List<Product> liSanPhams = new ArrayList<Product>();
		liSanPhams = entityManager.createQuery("select p from Product p where status = 1 ORDER BY p.date DESC")
				.setMaxResults(20).getResultList();
		return liSanPhams;

	}

	@SuppressWarnings("unchecked")
	@Transactional
	public List<Product> discount() {
		List<Product> liSanPhams = new ArrayList<Product>();
		liSanPhams = entityManager
				.createQuery("select p from Product p where status = 1  ORDER BY (price-price_new) desc")
				.setMaxResults(20).getResultList();
		return liSanPhams;

	}

//	@Transactional
//	public SanPham layDSSPTheoMa(int masp) {
//		Session session = sessionFactory.getCurrentSession();
//		String query = "from sanpham where masanpham=" + masp;
//		SanPham sanPham = (SanPham) session.createQuery(query).getSingleResult();
//		return sanPham;
//
//	}

//	@Transactional
//	public List<SanPham> layDSSPTheoDM(int madanhmuc) {
//		Session session = sessionFactory.getCurrentSession();
//		String query= "from sanpham where madanhmuc="+madanhmuc;
//		List<SanPham> liSanPhams= (List<SanPham>) session.createQuery(query).getResultList();
//		return liSanPhams;
//	}
//	@Transactional
//	public boolean xoaSPTheoMaSp(int masanpham) {
//		Session session = sessionFactory.getCurrentSession();
//		SanPham sanPham= session.get(SanPham.class, masanpham);
//		
//		Set<ChiTietSanPham> chiTietSanPhams= sanPham.getChitietsanpham();
//		for (ChiTietSanPham chiTietSanPham : chiTietSanPhams) {
//			session.createQuery("delete chitiethoadon where machitietsanpham="+ chiTietSanPham.getMachitietsanpham()).executeUpdate();
//		}
//		session.createQuery("delete chitietsanpham where masanpham="+ masanpham).executeUpdate();
//		session.createQuery("delete sanpham where masanpham="+ masanpham).executeUpdate();
//		return false;
//	}
//	@Transactional
//	public boolean themSanPham(SanPham sanPham) {
//		Session session = sessionFactory.getCurrentSession();
//		int id=  (Integer) session.save(sanPham);
//		return false;
//	}
//	@Transactional
//	public boolean capNhatSanPham(SanPham sanPham) {
//		Session session = sessionFactory.getCurrentSession();
//		session.update(sanPham);
//		return false;
//	}

	@Override
	public List<Product> layDSSanPham(int spbatdau) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product laySPTheoMa(int masp) {
		return productRepository.findById(masp).get();

	}

	@SuppressWarnings("unchecked")
	@Transactional
	public List<Product> layDSSPTheoDM(int idcategory) {
//		List<Product> liSanPhams = new ArrayList<Product>();
//		liSanPhams = entityManager
//				.createQuery("select p from Product p where status = 1  and idcategory = " + idcategory)
//				.getResultList();
		return productRepository.layDSSPTheoDM(idcategory);

	}

	@Override
	public boolean xoaSPTheoMaSp(int masanpham) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean themSanPham(Product sanPham) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean capNhatSanPham(Product sanPham) {
		// TODO Auto-generated method stub
		return false;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Product> seach(String value) {
		List<Product> liSanPhams = new ArrayList<Product>();
		liSanPhams = entityManager.createQuery("select p from Product p where price like '%" + value
				+ "%' or name like '%" + value + "%' or price like '%" + value + "%' or price_new like '%" + value
				+ "%' or back_camera like '%" + value + "%' or cpu like '%" + value + "%' or date like '%" + value
				+ "%' or description like '%" + value + "%' or front_camera like '%" + value
				+ "%' or operating_system like '%" + value + "%' or ram like '%" + value + "%' or screen like '%"
				+ value + "%' ").getResultList();
		return liSanPhams;
	}

	@Override
	public Optional<Product> getfindByID(int idproduct) {
		return productRepository.findById(idproduct);
	}

	@Override
	public void saveProduct(Product product, int idmenu) {
		Menu menu = productRepository.findMenuById(idmenu);
		product.setMenu_product(menu);
		productRepository.save(product);
	}

	@Transactional
	@Override
	public void updateProduct(Product product, int parseInt) {
		Menu menu = menuRepository.findMenuById(parseInt);
		product.setMenu_product(menu);
		entityManager.createNativeQuery("UPDATE `cdw`.`product` SET `back_camera` = ? , `count` = ? , `cpu` = ? ,"
				+ " `description` = ?, `front_camera` = ?, `name` = ?, `operating_system` = ?, "
				+ "`price` = ?, `price_new` = ?, `ram` = ?, `screen` = ?, `so_luong_con` = ? ,  `idmenu` = ? WHERE `idproduct` = ?")
				.setParameter(1, product.getBack_camera()).setParameter(2, product.getCount())
				.setParameter(3, product.getCpu()).setParameter(4, product.getDescription())
				.setParameter(5, product.getFront_camera()).setParameter(6, product.getName())
				.setParameter(7, product.getOperating_system()).setParameter(8, product.getPrice())
				.setParameter(9, product.getPrice_new()).setParameter(10, product.getRam())
				.setParameter(11, product.getScreen()).setParameter(12, product.getSo_luong_con())
				.setParameter(13, parseInt).setParameter(14, product.getIdproduct()).executeUpdate();
	}

	@Override
	public void deleteById(int idproduct) {
		productRepository.deleteById(idproduct);

	}

	@Override
	public void updateProduct(Product product) {
		// TODO Auto-generated method stub
		
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<Product> findAll() {
		// TODO Auto-generated method stub
		return productRepository.findAll();
	}


}
