package com.hellokoding.auth.servicee;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hellokoding.auth.modell.Shopping_Cart;
import com.hellokoding.auth.repositoryy.ShoppingCartProductReponsitory;

@Service
public class ShoppingCartServiceImpl implements ShoppingCartService {
	@Autowired
	private ShoppingCartProductReponsitory cartProductReponsitory;

	@Override
	public void save(Shopping_Cart cart) {
		// TODO Auto-generated method stub

	}

	@Override
	public Shopping_Cart findByUserKH(String userKH) {
		return cartProductReponsitory.findByUserKH(userKH);
	}

}
