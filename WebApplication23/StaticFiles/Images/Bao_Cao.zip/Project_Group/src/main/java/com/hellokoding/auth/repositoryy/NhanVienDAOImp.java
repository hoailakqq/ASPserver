//package com.hellokoding.auth.repositoryy;
//
//import com.hellokoding.auth.modell.User;
//
//public interface NhanVienDAOImp {
//	boolean ktDangNhap(String email, String matkhau);
//
//	boolean themNhanVien(User nhanVien);
//
//	boolean ktemail(String email);
//}
