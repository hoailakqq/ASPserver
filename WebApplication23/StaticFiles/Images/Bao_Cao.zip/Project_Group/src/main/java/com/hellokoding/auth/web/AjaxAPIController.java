//package com.hellokoding.auth.web;
//
//import java.io.File;
//import java.io.IOException;
//import java.text.DecimalFormat;
//import java.util.ArrayList;
//import java.util.HashSet;
//import java.util.Iterator;
//import java.util.List;
//import java.util.Set;
//import java.util.regex.Matcher;
//import java.util.regex.Pattern;
//
//import javax.servlet.ServletContext;
//import javax.servlet.http.HttpSession;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.ModelMap;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.ModelAttribute;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.bind.annotation.SessionAttributes;
//import org.springframework.web.multipart.MultipartFile;
//import org.springframework.web.multipart.MultipartHttpServletRequest;
//
//import com.fasterxml.jackson.core.JsonParseException;
//import com.fasterxml.jackson.databind.JsonMappingException;
//import com.fasterxml.jackson.databind.JsonNode;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.hellokoding.auth.servicee.NhanVienService;
//
//@Controller
//@RequestMapping("api/")
//@SessionAttributes({ "taikhoan", "giohang" })
//public class AjaxAPIController {
//	@Autowired
//	NhanVienService nvservice;
//
////	@Autowired
////	SanPhamService sanPhamService;
//
//	@GetMapping("ktdangnhap")
//	@ResponseBody
//	public String loginControl(@RequestParam String email, @RequestParam String password, ModelMap map) {
//		boolean kt = nvservice.ktDangNhap(email, password);
//		map.addAttribute("taikhoan", email);
//		return "" + kt;
//
//	}
//
////	@PostMapping("ktdangki")
////	@ResponseBody
////	public String dangKi(@RequestParam String tendk, @RequestParam String emaildk, @RequestParam String passworddk,
////			@RequestParam String repassworddk, ModelMap map) {
////		boolean checkmail = validate(emaildk);
////		boolean ktmail = nvservice.ktemail(emaildk);
////		if (checkmail && ktmail) {
////			if (passworddk.equals(repassworddk)) {
////				NhanVien nhanVien = new NhanVien();
////				nhanVien.setEmail(emaildk);
////				nhanVien.setTendangnhap(emaildk);
////				nhanVien.setMatkhau(passworddk);
////				nhanVien.setDiachi("tp.HCM");
////				nhanVien.setTennhanvien(tendk);
////
////				boolean kt = nvservice.themNhanVien(nhanVien);
////				map.addAttribute("taikhoan", emaildk);
////				return "" + kt;
////			} else {
////				return "errorPass";
////			}
////		} else {
////			return "errorEmail";
////		}
////	}
////
////	// check email
////	public static final Pattern VALID_EMAIL_ADDRESS_REGEX = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$",
////			Pattern.CASE_INSENSITIVE);
////
////	public static boolean validate(String emailStr) {
////		Matcher matcher = VALID_EMAIL_ADDRESS_REGEX.matcher(emailStr);
////		return matcher.find();
////	}
////
////	@GetMapping("themgiohang")
////	@ResponseBody
////	public String themGioHang(@RequestParam int machitiet, @RequestParam int masp, @RequestParam int mamau,
////			@RequestParam int masize, @RequestParam int soluong, @RequestParam String tensp,
////			@RequestParam String giatien, @RequestParam String tenmau, @RequestParam String tensize,
////			HttpSession httpSession) {
////		if (null == httpSession.getAttribute("giohang")) {
////			List<GioHang> gioHangs = new ArrayList<GioHang>();
////			GioHang gioHang = new GioHang();
////			gioHang.setMachitiet(machitiet);
////			gioHang.setMasp(masp);
////			gioHang.setMamau(mamau);
////			gioHang.setMasize(masize);
////			gioHang.setSoluong(1);
////			gioHang.setTensp(tensp);
////			gioHang.setGiatien(giatien);
////			gioHang.setTenmau(tenmau);
////			gioHang.setTensize(tensize);
////			gioHangs.add(gioHang);
////			httpSession.setAttribute("giohang", gioHangs);
////			System.out.println("da them 1 sp");
////
////			return gioHangs.size() + "";
////		} else {
////			List<GioHang> gioHangs = (List<GioHang>) httpSession.getAttribute("giohang");
////			int vitri = ktspTonTai(masp, masize, mamau, gioHangs);
////			if (vitri == -1) {
////				GioHang gioHang = new GioHang();
////				gioHang.setMachitiet(machitiet);
////				gioHang.setMasp(masp);
////				gioHang.setMamau(mamau);
////				gioHang.setMasize(masize);
////				gioHang.setSoluong(1);
////				gioHang.setTensp(tensp);
////				gioHang.setGiatien(giatien);
////				gioHang.setTenmau(tenmau);
////				gioHang.setTensize(tensize);
////				gioHangs.add(gioHang);
////
////				System.out.println("da them 1 sp");
////
////			} else {
////				int soluongmoi = gioHangs.get(vitri).getSoluong() + 1;
////				gioHangs.get(vitri).setSoluong(soluongmoi);
////				System.out.println("dacap nhat" + soluongmoi);
////
////			}
////			return gioHangs.size() + "";
////		}
////
////	}
////
////	private int ktspTonTai(int masp, int masize, int mamau, List<GioHang> list) {
////		for (int i = 0; i < list.size(); i++) {
////			if (list.get(i).getMasp() == masp && list.get(i).getMasize() == masize && list.get(i).getMamau() == mamau) {
////				return i;
////			}
////		}
////
////		return -1;
////	}
////
////	@GetMapping("updatesl")
////	@ResponseBody
////	public void updateSL(@RequestParam int soluong, @RequestParam int masp, @RequestParam int mamau,
////			@RequestParam int masize, HttpSession httpSession) {
////		if (null != httpSession.getAttribute("giohang")) {
////			List<GioHang> gioHangs = (List<GioHang>) httpSession.getAttribute("giohang");
////			int vitri = ktspTonTai(masp, masize, mamau, gioHangs);
////			gioHangs.get(vitri).setSoluong(soluong);
////
////		}
////
////	}
////
////	@GetMapping("xoaspgiohang")
////	@ResponseBody
////	public void xoaspgiohang(@RequestParam int masp, @RequestParam int mamau, @RequestParam int masize,
////			HttpSession httpSession) {
////		if (null != httpSession.getAttribute("giohang")) {
////			List<GioHang> gioHangs = (List<GioHang>) httpSession.getAttribute("giohang");
////			int vitri = ktspTonTai(masp, masize, mamau, gioHangs);
////			gioHangs.remove(vitri);
////
////		}
////
////	}
////
////	@GetMapping(path="laysplimit",produces="plain/text;charset=utf-8")
////	@ResponseBody
////	public String laySPLimit(@RequestParam int spbatdau) {
////		List<SanPham> sanPhams= sanPhamService.layDSSanPham(spbatdau);
////		
////		String html="";
////		for (SanPham sanPham : sanPhams) {
////			html+="<tr>";
////			html+= "<td><div class='checkbox'><label><input class='checkboxsp' type='checkbox' value='"+sanPham.getMasanpham()+"'></label></div></td>";
////			html+="<td class='tensp' data-masp='"+sanPham.getMasanpham()+"'>"+sanPham.getTensanpham()+"</td>";
////			html+="<td class='giasp' data-value='"+sanPham.getGia()+"'>"+sanPham.getGia()+"</td>";
////			html+="<td class='capnhatsanpham' data-id='"+sanPham.getMasanpham()+"' ><button class='btn btn-success'>Cập nhật</button></td>";		
////			html+="</tr>";
////		}
////		return html;
////				
////	}
////	
////	@GetMapping("xoasanpham")
////	@ResponseBody
////	public String xoaSanPham(@RequestParam int masanpham){
////		sanPhamService.xoaSPTheoMaSp(masanpham);
////		
////		return "";
////	}
////	
////	@Autowired
////	ServletContext context;
////	
////	@PostMapping("uploadfile")
////	@ResponseBody
////	public String uploadSanPham(MultipartHttpServletRequest request){
////		String path_save_file= context.getRealPath("/resources/img/SanPham/");
////		Iterator<String> listnames= request.getFileNames();
////		MultipartFile file= request.getFile(listnames.next());
////		
////		File file_save=new File(path_save_file + file.getOriginalFilename());
////		System.out.println(path_save_file);
////		try {
////			file.transferTo(file_save);
////		} catch (IllegalStateException e) {
////			// TODO Auto-generated catch block
////			e.printStackTrace();
////		} catch (IOException e) {
////			// TODO Auto-generated catch block
////			e.printStackTrace();
////		}
////		return "true";
////	}
////	
////	@PostMapping("themsanpham")
////	@ResponseBody
////	public void themSanPham(@RequestParam String dataJson){
////		ObjectMapper objectMapper = new ObjectMapper();
////		JsonNode jsonNode;
////		try {
////			SanPham sanPham= new SanPham();
////			jsonNode = objectMapper.readTree(dataJson);
////			
////			DanhMucSanPham danhMucSanPham= new DanhMucSanPham();
////			danhMucSanPham.setMadanhmuc(jsonNode.get("danhmucsanpham").asInt());
////			
////			JsonNode jsonchitietsp= jsonNode.get("chitietsanpham");
////			
////			Set<ChiTietSanPham> chiTietSanPhams= new HashSet<ChiTietSanPham>();
////			for (JsonNode objchitiet : jsonchitietsp) {
////				ChiTietSanPham chiTietSanPham= new ChiTietSanPham();
////				
////				MauSanPham mauSanPham= new MauSanPham();
////				mauSanPham.setMamau(objchitiet.get("mausanpham").asInt());
////				
////				KichThuoc kichThuoc= new KichThuoc();
////				kichThuoc.setMakichthuoc(objchitiet.get("kichthuoc").asInt());
////				
////				chiTietSanPham.setMausanpham(mauSanPham);
////				chiTietSanPham.setKichthuoc(kichThuoc);
////				chiTietSanPham.setSoluong(objchitiet.get("soluong").asInt());
////				
////				chiTietSanPhams.add(chiTietSanPham);			
////			}
////			
////			String tensanpham= jsonNode.get("tensanpham").asText();
////			int gia= jsonNode.get("gia").asInt();
////			String mota= jsonNode.get("mota").asText();
////			String hinhsanpham= jsonNode.get("hinhsanpham").asText();
////			
////			sanPham.setChitietsanpham(chiTietSanPhams);
////			sanPham.setDanhmucsanpham(danhMucSanPham);
////			sanPham.setTensanpham(tensanpham);
////			sanPham.setGia(gia);
////			sanPham.setMota(mota);
////			sanPham.setHinhsanpham(hinhsanpham);
////			
////			sanPhamService.themSanPham(sanPham);
////			
////			
////		} catch (IOException e) {
////			// TODO Auto-generated catch block
////			e.printStackTrace();
////		}
////	}
////	
////
////	@PostMapping(path="laysanphamtheoma",produces="application/json;charset=utf-8")
////	@ResponseBody
////	public JSON_SanPham laySanPhamTheoMa(@RequestParam int masanpham){
////		JSON_SanPham json_SanPham= new JSON_SanPham();
////		
////		SanPham sanPham= sanPhamService.layDSSPTheoMa(masanpham);
////		
////		json_SanPham.setMasanpham(sanPham.getMasanpham());
////		json_SanPham.setTensanpham(sanPham.getTensanpham());
////		json_SanPham.setGia(sanPham.getGia());
////		json_SanPham.setMota(sanPham.getMota());
////		json_SanPham.setHinhsanpham(sanPham.getHinhsanpham());
////		
////		DanhMucSanPham danhMucSanPham= new DanhMucSanPham();
////		danhMucSanPham.setMadanhmuc(sanPham.getDanhmucsanpham().getMadanhmuc());
////		danhMucSanPham.setTendanhmuc(sanPham.getDanhmucsanpham().getTendanhmuc());
////		json_SanPham.setDanhmucsanpham(danhMucSanPham);
////		
////		Set<ChiTietSanPham> chiTietSanPhams = new HashSet<ChiTietSanPham>();
////		for (ChiTietSanPham value : sanPham.getChitietsanpham()) {
////			ChiTietSanPham chiTietSanPham= new ChiTietSanPham();
////			chiTietSanPham.setMachitietsanpham(value.getMachitietsanpham());
////			
////			KichThuoc kichThuoc =new KichThuoc();
////			kichThuoc.setMakichthuoc(value.getKichthuoc().getMakichthuoc());
////			kichThuoc.setTenkichthuoc(value.getKichthuoc().getTenkichthuoc());
////			chiTietSanPham.setKichthuoc(kichThuoc);
////			
////			MauSanPham mauSanPham = new MauSanPham();
////			mauSanPham.setMamau(value.getMausanpham().getMamau());
////			mauSanPham.setTenmau(value.getMausanpham().getTenmau());
////			chiTietSanPham.setMausanpham(mauSanPham);
////			
////			chiTietSanPham.setSoluong(value.getSoluong());
////			
////			chiTietSanPhams.add(chiTietSanPham);
////		}
////		json_SanPham.setChitietsanpham(chiTietSanPhams);
////		
////		
////		return json_SanPham;
////	}
////	
////	@PostMapping("capnhatsanpham")
////	@ResponseBody
////	public void	capNhatSPTheoMma(@RequestParam String dataJson){
////		ObjectMapper objectMapper = new ObjectMapper();
////		JsonNode jsonNode;
////		try {
////			SanPham sanPham= new SanPham();
////			jsonNode = objectMapper.readTree(dataJson);
////			
////			DanhMucSanPham danhMucSanPham= new DanhMucSanPham();
////			danhMucSanPham.setMadanhmuc(jsonNode.get("danhmucsanpham").asInt());
////			
////			JsonNode jsonchitietsp= jsonNode.get("chitietsanpham");
////			
////			Set<ChiTietSanPham> chiTietSanPhams= new HashSet<ChiTietSanPham>();
////			for (JsonNode objchitiet : jsonchitietsp) {
////				ChiTietSanPham chiTietSanPham= new ChiTietSanPham();
////				
////				MauSanPham mauSanPham= new MauSanPham();
////				mauSanPham.setMamau(objchitiet.get("mausanpham").asInt());
////				
////				KichThuoc kichThuoc= new KichThuoc();
////				kichThuoc.setMakichthuoc(objchitiet.get("kichthuoc").asInt());
////				
////				chiTietSanPham.setMausanpham(mauSanPham);
////				chiTietSanPham.setKichthuoc(kichThuoc);
////				chiTietSanPham.setSoluong(objchitiet.get("soluong").asInt());
////				
////				chiTietSanPhams.add(chiTietSanPham);			
////			}
////			
////			String tensanpham= jsonNode.get("tensanpham").asText();
////			int gia= jsonNode.get("gia").asInt();
////			String mota= jsonNode.get("mota").asText();
////			String hinhsanpham= jsonNode.get("hinhsanpham").asText();
////			int masanpham=jsonNode.get("masanpham").asInt();
////			
////			sanPham.setChitietsanpham(chiTietSanPhams);
////			sanPham.setDanhmucsanpham(danhMucSanPham);
////			sanPham.setTensanpham(tensanpham);
////			sanPham.setGia(gia);
////			sanPham.setMota(mota);
////			sanPham.setHinhsanpham(hinhsanpham);
////			sanPham.setMasanpham(masanpham);
////			
////			sanPhamService.capNhatSanPham(sanPham);
////			
////			
////		} catch (IOException e) {
////			// TODO Auto-generated catch block
////			e.printStackTrace();
////		}
////	}
//}
