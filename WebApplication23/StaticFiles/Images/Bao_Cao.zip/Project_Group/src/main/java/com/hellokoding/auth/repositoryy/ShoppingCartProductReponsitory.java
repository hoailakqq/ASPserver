package com.hellokoding.auth.repositoryy;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hellokoding.auth.modell.Shopping_Cart;

public interface ShoppingCartProductReponsitory extends JpaRepository<Shopping_Cart, Long> {

	public Shopping_Cart findByUserKH(String userKH);
}
