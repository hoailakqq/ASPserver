package com.hellokoding.auth.web;

import java.util.List;

import javax.persistence.EntityManager;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.hellokoding.auth.modell.Category;
import com.hellokoding.auth.modell.Menu;
import com.hellokoding.auth.servicee.CategoryService;
import com.hellokoding.auth.servicee.MenuService;

@Controller
public class CateryController {
	@Autowired
	MenuService menuService;
	@Autowired
	CategoryService categoryService;
	@Autowired
	private EntityManager entityManager;

	@GetMapping("/quanlyCatory")
	public String ListCatory(Model model) {
		List<Category> categorys = categoryService.findAll();
		for (int i = 0; i < categorys.size(); i++) {
			model.addAttribute("category", categorys);
			System.out.println(categorys.size());
		}

		return "quanly_catory";
	}

	@RequestMapping(value = "/delete_Cate", method = RequestMethod.GET)
	public String xoaSanPham(@RequestParam int idcategory, RedirectAttributes redirect) {
		categoryService.deleteById(idcategory);
		return "redirect:/quanlyCatory	";
	}

	@RequestMapping(value = "update_Cate", method = RequestMethod.GET)
	public String showUpdate(@RequestParam int idcategory, ModelMap model) {
		Category category = categoryService.getfindByID(idcategory).get();
		model.put("menu", menuService.findAll());
		model.put("category", category);
		return "sua_cate";
	}

	@RequestMapping(value = "update_Cate" , method = RequestMethod.POST)
	public String updateUser(ModelMap model, @Valid Category category,@Valid Menu menu, BindingResult result
			,RedirectAttributes redirect) {
		
		if(result.hasErrors()) {
			return "sua_cate";
		}
		
		categoryService.updateCate(category);
		return "redirect:/quanlyCatory";
	}
}
