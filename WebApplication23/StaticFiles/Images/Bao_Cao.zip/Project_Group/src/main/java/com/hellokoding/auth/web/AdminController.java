package com.hellokoding.auth.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.hellokoding.auth.modell.User;
import com.hellokoding.auth.modell.User_Roles;
import com.hellokoding.auth.servicee.UserService;
import com.hellokoding.auth.servicee.User_RoleSerivce;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

@Controller
public class AdminController {

	@Autowired
	UserService userService;

	@Autowired
	User_RoleSerivce user_RoleSerivce;

	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	@PersistenceContext
	private EntityManager entityManager;

	@GetMapping("/admin")
	public String viewPersonList3(Model model) {
		List<User> users = userService.findAll();
		for (int i = 0; i < users.size(); i++) {
			model.addAttribute("user", users);
			System.out.println(users.size());

		}
		System.out.println("111");
		return "quanly_user";
	}

	@GetMapping("/add_User")
	public String viewPersonSua(Model model, HttpSession session) {

		User user = (User) session.getAttribute("userss");
		if (user.getUserRole().getUsers_iduser() == 1) {
			model.addAttribute("userss", user);

			return "add_user";
		} else
			return "login";
	}

//	@Transactional
//	@RequestMapping(value = { "/add" }, method = RequestMethod.POST)
//	@ResponseBody
//	public String viewEdit(String username,String pass,
//			String email,  String ho_Ten,
//			String user_role,boolean status, ModelMap map) {
//		User getuser = userService.findByUsername(username);
//		if (getuser.getUserRole().getName().equals("admin")) {
//			user_role = "1";
//		} else {
//			getuser.getUserRole().getName().equals("user");
//			user_role = "0";
//		}
//
//		User user = new User(username, pass, email, ho_Ten, new User_Roles((long) 0, "user"), status);
//		
////		return (getuser == null) ? insertWithQuery(user) : false;
//		return username;
//	}

//	@RequestMapping("/addUser")
//	public String addUser(@ModelAttribute("userss") User user, Model model) {
//		model.addAttribute("userss", user);
//		System.out.println(user.getUsername());
//		return "admin";
//	}
//	@Transactional
//	private boolean insertWithQuery(User user) {
//		long a = 0;
//		if (user.getUserRole().getName().equals("admin")) {
//			a = 1;
//		} else {
//			user.getUserRole().getName().equals("user");
//			a = 0;
//		}
//		entityManager.createNativeQuery(
//				"INSERT INTO `web`.`user`(`username`, `pass`, `email`, `ho_ten`, `status`, `users_iduser`) VALUES (?, ?, ?, ?, ?, ?)")
//				.setParameter(1, user.getUsername()).setParameter(2, user.getPass()).setParameter(3, user.getEmail())
//				.setParameter(4, user.getHoTen()).setParameter(5, true)
//				.setParameter(6, new User_Roles((long) 0, "user")).executeUpdate();
//
//		return true;
//	}

	@RequestMapping(value = "/delete", method = RequestMethod.GET)

	public String xoaUser(@RequestParam int iduser, RedirectAttributes redirect) {
		userService.deleteById(iduser);
		return "redirect:/admin";
	}

	@RequestMapping(value = "/update_product", method = RequestMethod.GET)
	public String showUpdate(@RequestParam int iduser, ModelMap model) {
		User user = userService.getfindByID(iduser).get();
		model.put("user", user);
		model.put("user_role", user_RoleSerivce.findAll());
		return "sua_user";
	}

	@RequestMapping(value = "/update_product", method = RequestMethod.POST)
	public String updateUser(ModelMap model,@ModelAttribute("user") User user, BindingResult result, RedirectAttributes redirect,HttpServletRequest request) {
		if (result.hasErrors()) {
			return "sua_user";
		}
		String role = request.getParameter("role");
		userService.updateUser(user, Integer.parseInt(role));
		model.put("user_role", user_RoleSerivce.findAll());
		return "redirect:/admin";
	}



	@RequestMapping(value = "/addUser", method = RequestMethod.GET)
	public String showAddTodoPage(ModelMap model) {
		model.addAttribute("user", new User());
		model.addAttribute("user_role", user_RoleSerivce.findAll());

		return "add_user";
	}

	@RequestMapping(value = "/addUser", method = RequestMethod.POST)
	public String addTodo(@ModelAttribute("user") User user,ModelMap model,  BindingResult result, RedirectAttributes redirect, HttpServletRequest request) {

		if (result.hasErrors()) {
			return "add_user";
		}
		String role = request.getParameter("role");
		userService.saveUser(user, Integer.parseInt(role));
		System.out.println(user.getUserRole().getName()+user.getUserRole().getUsers_iduser());

		return "redirect:/admin";
	}
}
