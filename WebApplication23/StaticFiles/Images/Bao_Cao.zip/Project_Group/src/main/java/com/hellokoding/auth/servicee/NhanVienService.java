//package com.hellokoding.auth.servicee;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.hellokoding.auth.modell.User;
//import com.hellokoding.auth.repositoryy.NhanVienDAOImp;
//import com.tpwin.dao.NhanVienDAO;
//
//@Service
//public class NhanVienService implements NhanVienDAOImp {
//
////	@Autowired
//	NhanVienDAO nvDao;
//
//	public boolean ktDangNhap(String email, String matkhau) {
//		return nvDao.ktDangNhap(email, matkhau);
//	}
//
//	public boolean themNhanVien(User nhanVien) {
//		boolean kt = nvDao.themNhanVien(nhanVien);
//		return kt;
//	}
//
//	public boolean ktemail(String email) {
//		return nvDao.ktemail(email);
//	}
//
//}
