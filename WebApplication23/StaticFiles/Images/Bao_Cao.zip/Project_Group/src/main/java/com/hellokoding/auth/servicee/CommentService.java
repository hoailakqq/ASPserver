package com.hellokoding.auth.servicee;

import java.util.List;

import com.hellokoding.auth.modell.Comment;

public interface CommentService {
	List<String> findComment(int idComment);
    List<Comment> findByComment(String comment);
	List<Comment> findCommentByPro(int idproduct);

}
