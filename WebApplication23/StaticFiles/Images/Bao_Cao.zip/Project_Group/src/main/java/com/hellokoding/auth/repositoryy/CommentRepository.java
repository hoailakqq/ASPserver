package com.hellokoding.auth.repositoryy;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hellokoding.auth.modell.Comment;
import com.hellokoding.auth.modell.User;

public interface CommentRepository extends JpaRepository<Comment, Integer> {
	@Query(value="select distinct(c.comments) from Comment c where idproduct=?1")
	List<String> findComment(int idComment);
	@Query(value="select c from Comment c where comments=?1")
    List<Comment> findByComment(String comment);
	@Query(value="select c from Comment c where idproduct=?1 order by date desc")
	List<Comment> findCommentByPro(int idComment);


}
