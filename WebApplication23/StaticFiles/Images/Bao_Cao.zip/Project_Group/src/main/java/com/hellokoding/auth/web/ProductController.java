package com.hellokoding.auth.web;

import java.sql.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.hellokoding.auth.modell.Category;
import com.hellokoding.auth.modell.Comment;
import com.hellokoding.auth.modell.Menu;
import com.hellokoding.auth.modell.Product;
import com.hellokoding.auth.modell.User;
import com.hellokoding.auth.modell.User_Roles;
import com.hellokoding.auth.repositoryy.CommentRepository;
import com.hellokoding.auth.repositoryy.ProductRepository;
import com.hellokoding.auth.servicee.CategoryService;
import com.hellokoding.auth.servicee.CommentServiceImpl;
import com.hellokoding.auth.servicee.MenuService;
import com.hellokoding.auth.servicee.ProductServiceImpl;
import com.mysql.cj.Session;

@Controller
public class ProductController {
	@Autowired
	MenuService menuService;
	@Autowired
	CategoryService categoryService;
	@Autowired
	ProductServiceImpl productService;
//	@Autowired
//	ProductServiceImpl productService;
	@Autowired
	CommentServiceImpl commentServiceImpl;
	
	@GetMapping("/quanlyPro")
	public String viewPersonList3(Model model) {
		List<Product> products = productService.findAll();
		for (int i = products.size()-1; i >0; i--) {
			model.addAttribute("product", products);
			System.out.println(products.size());

		}
		System.out.println("111");
		return "quanly_sanpham";
	}

	@GetMapping("/product/{idcategory}/{name}")
	public String welcome(Model model, @PathVariable int idcategory, @PathVariable String name) {
		List<Menu> menus = menuService.findAll();
		for (int i = 0; i < menus.size(); i++) {
			System.out.println("log: " + menus.get(i).toString());
			model.addAttribute("menus", menus);
			List<Category> categorys = categoryService.findCategory(i);
			System.out.println(menus.get(i).getName());
			for (int j = 0; j < categorys.size(); j++) {

				System.out.println("log: " + categorys.get(j).getName());
				System.out.println(categorys.size());
			}
			System.out.println("category" + i);
			model.addAttribute("categorys" + i, categorys);
		}
		List<Product> product = productService.layDSSPTheoDM(idcategory);
		model.addAttribute("product", product);
		model.addAttribute("name", name);
		for (int j = 0; j < product.size(); j++) {
			System.out.println("log: " + product.get(j).getName());
			System.out.println(product.size());
		}

		return "product";
	}

	@GetMapping("/detailProduct/{idproduct}/{name}")
	public String detailProduct(Model model, @PathVariable int idproduct, @PathVariable String name) {
		List<Menu> menus = menuService.findAll();
		for (int i = 0; i < menus.size(); i++) {
			System.out.println("log: " + menus.get(i).toString());
			model.addAttribute("menus", menus);
			List<Category> categorys = categoryService.findCategory(i);
			System.out.println(menus.get(i).getName());
			for (int j = 0; j < categorys.size(); j++) {

				System.out.println("log: " + categorys.get(j).getName());
				System.out.println(categorys.size());
			}
			System.out.println("category" + i);
			model.addAttribute("categorys" + i, categorys);
		}
		Product product = productService.laySPTheoMa(idproduct);
		model.addAttribute("product", product);
		model.addAttribute("name", name);
		System.out.println("log: " + product.getName());
		List<Comment> comment = commentServiceImpl.findCommentByPro(idproduct);
		model.addAttribute("comment", comment);
//		for (int j = 0; j < comment.size(); j++) {
//			List<Comment> comments = commentServiceImpl.findByComment(comment.get(j).getComment());
//			System.out.println(comment.size());
//			for (int k = 0; k < comments.size(); k++) {
//				System.out.println(comments.get(k).getComment()+comments.get(k).getAnswer());
//			}
//			model.addAttribute("comments", comments);
//			System.out.println(comments.get(0).getComment());
//			System.out.println(comments.get(1).getComment());
//			System.out.println(comments.get(2).getComment());
//			System.out.println(comments.get(3).getComment());

		return "detailproduct";

	}

//	@PostMapping("/comment")
//	@ResponseBody
//	public String comment(Model model, String comment) {
//
//		List<Comment> comments = commentServiceImpl.findByComment(comment);
//		String kt = "1";
//		System.out.println(comments.size() + "size & comment" + comment);
//		System.out.println(comments.get(0).getAnswer());
//		System.out.println(comments.get(1).getAnswer());
//		System.out.println(comments.get(2).getAnswer());
//		System.out.println(comments.get(3).getAnswer());
//		model.addAttribute("comments", comments);
//		return kt + "";
//	}

	@GetMapping("/seach")
	public String welcome(Model model, @RequestParam("Product") String Product) {
		List<Menu> menus = menuService.findAll();
		for (int i = 0; i < menus.size(); i++) {
			System.out.println("log: " + menus.get(i).toString());
			model.addAttribute("menus", menus);
			List<Category> categorys = categoryService.findCategory(i);
			System.out.println(menus.get(i).getName());
			for (int j = 0; j < categorys.size(); j++) {
				System.out.println("log: " + categorys.get(j).getName());
				System.out.println(categorys.size());
			}
			System.out.println("category" + i);
			model.addAttribute("categorys" + i, categorys);

			model.addAttribute("Product", Product);
			List<Product> product = productService.seach(Product);
			for (int j = 0; j < product.size(); j++) {
				System.out.println("log: " + product.get(j).getName());
				System.out.println(product.size());
			}
			model.addAttribute("product", product);
		}
		return "seach";
	}

	@PersistenceContext
	private EntityManager entityManager;

	@Transactional
	public boolean insertComment(String comments, int idproduct) {
//		long millis = System.currentTimeMillis();
//		java.sql.Date dates = new java.sql.Date(millis);
		long millis = System.currentTimeMillis();
		java.util.Date dates = new java.util.Date(millis);
		entityManager.createNativeQuery("Insert into comment (comments, idproduct,date) values(?,?,?)")
				.setParameter(1, comments).setParameter(2, idproduct).setParameter(3, dates).executeUpdate();
		return true;
	}
	
	
	
	@RequestMapping(value = "/delete_product", method = RequestMethod.GET)
	public String xoaSanPham(@RequestParam int idproduct, RedirectAttributes redirect) {
		productService.deleteById(idproduct);
		return "redirect:quanlyPro	";
	}

	@RequestMapping(value = "/updateproduct", method = RequestMethod.GET)
	public String showUpdate(@RequestParam int idproduct, ModelMap model) {
		Product product = productService.getfindByID(idproduct).get();
		model.put("product", product);
		model.put("menu", menuService.findAll());

		return "sua_product";
	}

	@RequestMapping(value = "/updateproduct", method = RequestMethod.POST)
	public String updateUser(ModelMap model,@ModelAttribute("product") Product product, BindingResult result, RedirectAttributes redirect,HttpServletRequest request) {
		if (result.hasErrors()) {
			return "sua_product";
		}
		String menu = request.getParameter("menu");
		model.put("menu", menuService.findAll());

		productService.updateProduct(product, Integer.parseInt(menu));
		return "redirect:/quanlyPro";
	}
	
	@RequestMapping(value = "/insertProduct", method = RequestMethod.GET)
	public String showAddTodoPage(ModelMap model) {
		model.addAttribute("product", new Product());
		model.put("menu", menuService.findAll());

		return "insert_product";
	}

	@RequestMapping(value = "/insertProduct", method = RequestMethod.POST)
	public String addTodo(@ModelAttribute("product") Product product,ModelMap model,  BindingResult result, RedirectAttributes redirect, HttpServletRequest request) {
		if (result.hasErrors()) {
			return "insert_product";
		}
		String menu = request.getParameter("menu");
		System.out.println(menu+" ");
		productService.saveProduct(product, Integer.parseInt(menu));
		return "redirect:/quanlyPro";
	}
	
	

	@Transactional
	@PostMapping("/sendComment/{idproduct}/{name}")
//	@ResponseBody
//	public String sendComment(@ModelAttribute("comment") Comment cm, Model model, @PathVariable int idproduct, @PathVariable String comments) {
	public String sendComment(Model model, @RequestParam("Comment") String comments,
			@RequestParam("idproduct") String idproduct, @RequestParam("name") String name) {
		List<Menu> menus = menuService.findAll();
		for (int i = 0; i < menus.size(); i++) {
			System.out.println("log: " + menus.get(i).toString());
			model.addAttribute("menus", menus);
			List<Category> categorys = categoryService.findCategory(i);
			System.out.println(menus.get(i).getName());
			for (int j = 0; j < categorys.size(); j++) {

				System.out.println("log: " + categorys.get(j).getName());
				System.out.println(categorys.size());
			}
			System.out.println("category" + i);
			model.addAttribute("categorys" + i, categorys);
		}
		Product product = productService.laySPTheoMa(Integer.parseInt(idproduct));
		model.addAttribute("product", product);
		model.addAttribute("name", name);
		System.out.println("log: " + product.getName());
		List<Comment> comment = commentServiceImpl.findCommentByPro(Integer.parseInt(idproduct));
		model.addAttribute("comment", comment);
		if (comments == "") {
			return "detailproduct";
		} else {
			boolean s = insertComment(comments, Integer.parseInt(idproduct));
			System.out.println(s);
			List<Comment> commentt = commentServiceImpl.findCommentByPro(Integer.parseInt(idproduct));
			model.addAttribute("comment", commentt);
//			return "redirect:detailProduct/1/Sam%20Sung%20J7%20Prime";
			return "detailproduct"; 
		}
		

//		return "oke";
	}
}
