package com.hellokoding.auth.modell;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "shopping_cart")
public class Shopping_Cart {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", nullable = false)
	private Long id;

//	@OneToOne(cascade = CascadeType.ALL)
//	@JoinColumn(name = "idUser", referencedColumnName = "idUser")
//	private String userKH;

	@Column(name = "userKH", nullable = false)
	private String userKH;

	@Column(name = "value", nullable = false)
	private String value;

	public Shopping_Cart(String userKH, String value) {
		super();
		this.userKH = userKH;
		this.value = value;
	}

	public Shopping_Cart() {
		super();
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUserKH() {
		return userKH;
	}

	public void setUserKH(String userKH) {
		this.userKH = userKH;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
