package com.hellokoding.auth.web;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.hellokoding.auth.modell.Category;
import com.hellokoding.auth.modell.Menu;
import com.hellokoding.auth.modell.Product;
import com.hellokoding.auth.repositoryy.ProductRepository;
import com.hellokoding.auth.servicee.CategoryService;
import com.hellokoding.auth.servicee.MenuService;
import com.hellokoding.auth.servicee.ProductServiceImpl;

@Controller
public class TopProductController {
	@Autowired
	MenuService menuService;
	@Autowired
	CategoryService categoryService;
	@Autowired
	ProductServiceImpl sanphamDAO;

	@RequestMapping(value = { "/bestSeller" }, method = RequestMethod.GET)
	public String welcome(Model model) {
//		List<Menu> menus = menuService.findAll();
//		for (int i = 0; i < menus.size(); i++) {
//			System.out.println("log: " + menus.get(i).toString());
//			model.addAttribute("menus", menus);
//			List<Category> categorys = categoryService.findCategory(i);
//			System.out.println(menus.get(i).getName());
//			for (int j = 0; j < categorys.size(); j++) {
//				System.out.println("log: " + categorys.get(j).getName());
//				System.out.println(categorys.size());
//			}
//			System.out.println("category" + i);
//			model.addAttribute("categorys" + i, categorys);
//		}
//		List<Product> products = sanphamDAO.dtNoiBat();
//		model.addAttribute("products", products);
//		List<Product> laptop = sanphamDAO.ltNoiBat();
//		model.addAttribute("laptops", laptop);
//		List<Product> phukien = sanphamDAO.pkNoiBat();
//		model.addAttribute("phukiens", phukien);
//
//		List<Product> tablet = sanphamDAO.tbNoiBat();
//		model.addAttribute("tablets", tablet);
//		
//		try {

		List<Product> seller = sanphamDAO.bestSeller();
		for (int j = 0; j < seller.size(); j++) {
//				System.out.println("log: " + seller.get(j).getName());
			System.out.println(seller.size());
		}
		model.addAttribute("bestSellers", seller);
//		} catch (Exception e) {
//			// TODO: handle exception
//		}
		return "vegetables";
	}

	@RequestMapping(value = { "/bestNew" }, method = RequestMethod.GET)
	public String bestnew(Model model) {
		try {
			List<Menu> menus = menuService.findAll();
			for (int i = 0; i < menus.size(); i++) {
				System.out.println("log: " + menus.get(i).toString());
				model.addAttribute("menus", menus);
				List<Category> categorys = categoryService.findCategory(i);
				System.out.println(menus.get(i).getName());
				for (int j = 0; j < categorys.size(); j++) {
					System.out.println("log: " + categorys.get(j).getName());
					System.out.println(categorys.size());
				}
				System.out.println("category" + i);
				model.addAttribute("categorys" + i, categorys);
			}

		} catch (Exception e) {
			System.out.println(e);
		}
		
		
		
//		List<Menu> menus = menuService.findAll();
//		for (int i = 0; i < menus.size(); i++) {
//			System.out.println("log: " + menus.get(i).toString());
//			model.addAttribute("menus", menus);
//			List<Category> categorys = categoryService.findCategory(i);
//			System.out.println(menus.get(i).getName());
//			for (int j = 0; j < categorys.size(); j++) {
//				System.out.println("log: " + categorys.get(j).getName());
//				System.out.println(categorys.size());
//			}
//			System.out.println("category" + i);
//			model.addAttribute("categorys" + i, categorys);
//		}
//		List<Product> products = sanphamDAO.dtNoiBat();
//		model.addAttribute("products", products);
//		List<Product> laptop = sanphamDAO.ltNoiBat();
//		model.addAttribute("laptops", laptop);
//		List<Product> phukien = sanphamDAO.pkNoiBat();
//		model.addAttribute("phukiens", phukien);
//
//		List<Product> tablet = sanphamDAO.tbNoiBat();
//		model.addAttribute("tablets", tablet);
//		
//		try {

//			for (int j = 0; j < seller.size(); j++) {
//				System.out.println("log: " + seller.get(j).getName());
//				System.out.println(seller.size());
//			}
		List<Product> seller = sanphamDAO.bestnew();
		model.addAttribute("bestNews", seller);
//		} catch (Exception e) {
//			// TODO: handle exception
//		}
		return "bestnew";

	}
	@RequestMapping(value = { "/bestdiscount" }, method = RequestMethod.GET)
	public String bestdiscount(Model model) {
//		List<Menu> menus = menuService.findAll();
//		for (int i = 0; i < menus.size(); i++) {
//			System.out.println("log: " + menus.get(i).toString());
//			model.addAttribute("menus", menus);
//			List<Category> categorys = categoryService.findCategory(i);
//			System.out.println(menus.get(i).getName());
//			for (int j = 0; j < categorys.size(); j++) {
//				System.out.println("log: " + categorys.get(j).getName());
//				System.out.println(categorys.size());
//			}
//			System.out.println("category" + i);
//			model.addAttribute("categorys" + i, categorys);
//		}
//		List<Product> products = sanphamDAO.dtNoiBat();
//		model.addAttribute("products", products);
//		List<Product> laptop = sanphamDAO.ltNoiBat();
//		model.addAttribute("laptops", laptop);
//		List<Product> phukien = sanphamDAO.pkNoiBat();
//		model.addAttribute("phukiens", phukien);
//
//		List<Product> tablet = sanphamDAO.tbNoiBat();
//		model.addAttribute("tablets", tablet);
//		
//		try {

//			for (int j = 0; j < seller.size(); j++) {
//				System.out.println("log: " + seller.get(j).getName());
//				System.out.println(seller.size());
//			}
//		} catch (Exception e) {
//			// TODO: handle exception
//		}
		List<Product> discount = sanphamDAO.discount();
		model.addAttribute("bestdiscount", discount);
		return "bestdiscount";
	}
	@Autowired
	ProductRepository prodRe;
	@GetMapping("/tutorials")
	public List<Product> getAllTutorials(@RequestParam(required = false) String title,
			@RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "1") int size) {

		try {
			List<Product> tutorials = new ArrayList<Product>();
			Pageable paging = PageRequest.of(page, size);

			Page<Product> pageTuts;
			if (title == null)
				pageTuts = prodRe.findAll(paging);
			else
				pageTuts = prodRe.findAll(paging);

			tutorials = pageTuts.getContent();

			return tutorials;
		} catch (Exception e) {
			return null;
		}
	}
	

	@RequestMapping(value = { "/bestNew2/{id}" }, method = RequestMethod.GET)
	public String bestnew(Model model,@PathVariable("id") int id) {
		try {
			List<Menu> menus = menuService.findAll();
			for (int i = 0; i < menus.size(); i++) {
				System.out.println("log: " + menus.get(i).toString());
				model.addAttribute("menus", menus);
				List<Category> categorys = categoryService.findCategory(i);
				System.out.println(menus.get(i).getName());
				for (int j = 0; j < categorys.size(); j++) {
					System.out.println("log: " + categorys.get(j).getName());
					System.out.println(categorys.size());
				}
				System.out.println("category" + i);
				model.addAttribute("categorys" + i, categorys);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		
		List<Product> seller = getAllTutorials("", id, 6);
		model.addAttribute("bestNews", seller);

		

		return "bestnew";

	}
}
