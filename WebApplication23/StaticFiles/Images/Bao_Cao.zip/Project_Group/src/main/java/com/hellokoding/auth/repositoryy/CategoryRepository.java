package com.hellokoding.auth.repositoryy;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hellokoding.auth.modell.Category;

public interface CategoryRepository extends JpaRepository<Category, Integer>{
//	List<Category> findAllById(int id);

	@Query(value = "select c from Category c where idmenu=?1")
	List<Category> lstCategory(int id);
	List<Category> findAll();

}
