package com.hellokoding.auth.servicee;

import java.util.List;
import java.util.Optional;

import com.hellokoding.auth.modell.Menu;

public interface MenuService {
	List<Menu> findAll();
//	List<Menu> findAll();

	void deleteAll();

	void deleteById(int id);

	Optional<Menu> getfindByID(int id);

	void updateMenu( Menu menu);
	void save(Menu menu);
}
