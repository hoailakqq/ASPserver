package com.hellokoding.auth.servicee;

import java.util.List;
import java.util.Optional;

import com.hellokoding.auth.modell.Product;

public interface ProductService {
	List<Product> findAll();

	List<Product> dtNoiBat();

	List<Product> layDSSanPham(int spbatdau);
	
	List<Product> seach(String value);

	Product laySPTheoMa(int masp);

	List<Product> layDSSPTheoDM(int madanhmuc);

	boolean xoaSPTheoMaSp(int masanpham);

	boolean themSanPham(Product sanPham);

	boolean capNhatSanPham(Product sanPham);
	void updateProduct( Product product);
	void deleteById(int idproduct);
	Optional<Product> getfindByID(int id);
	void saveProduct(Product product, int idmenu);
	void updateProduct(Product product, int parseInt);
}
