package com.hellokoding.auth.repositoryy;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hellokoding.auth.modell.Menu;

public interface MenuRepository extends JpaRepository<Menu, Long> {
	@Query(value = "SELECT u FROM Menu u  WHERE u.idmenu = ?1")
	List<Menu> lstMenu(int id);

	@Query(value = "SELECT m FROM Menu m  WHERE m.idmenu = ?1")
	Menu findMenuById(int parseInt);
}
