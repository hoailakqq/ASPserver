package com.hellokoding.auth.servicee;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.hibernate.annotations.NamedQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hellokoding.auth.modell.Comment;
import com.hellokoding.auth.repositoryy.CommentRepository;
@Service
public class CommentServiceImpl implements CommentService {
	@Autowired
	CommentRepository commentRepository;
//	@NamedQuery(name="Comment.listUniqueNames",query="select DISTINCT(c.comment) c from Comment c where idproduct=?1")

	@Autowired
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<String> findComment(int idProduct) {
		return commentRepository.findComment(idProduct);
//		return entityManager.createNamedQuery("Comment.listUniqueNames",String.class).getResultList();
	}

	@Override
	public List<Comment> findByComment(String comment) {
		// TODO Auto-generated method stub
		return commentRepository.findByComment(comment);
	}

	@Override
	public List<Comment> findCommentByPro(int idproduct) {
		// TODO Auto-generated method stub
		return commentRepository.findCommentByPro(idproduct);
	}

}
