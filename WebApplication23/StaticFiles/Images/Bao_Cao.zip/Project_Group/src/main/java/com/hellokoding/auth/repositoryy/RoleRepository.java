package com.hellokoding.auth.repositoryy;

import com.hellokoding.auth.modell.User_Roles;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface RoleRepository extends JpaRepository<User_Roles, Integer>{
	  @Query(value ="SELECT u FROM User_Roles u  WHERE u.users_iduser = ?1")
	   User_Roles findUserRole(int idRole);
}
