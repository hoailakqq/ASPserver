package com.hellokoding.auth.servicee;

import java.util.List;
import java.util.Optional;

import com.hellokoding.auth.modell.Category;

public interface CategoryService {
	List<Category> findAll();

	List<Category> findCategory(int i);
	
	Category find(int id);
	
	 void deleteAll();
	 void deleteById(int id);

	void updateCate( Category category);
	Optional<Category> getfindByID(int id);

}
