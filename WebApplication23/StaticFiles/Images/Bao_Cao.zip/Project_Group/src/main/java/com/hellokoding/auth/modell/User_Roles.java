package com.hellokoding.auth.modell;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnore;
//import com.unknown.bookadmin.entity.User;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "user_roles")
public class User_Roles {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "users_iduser", nullable = false)
	private Integer users_iduser;

	@NotBlank(message = "Tên không được trống")
	@Column(name = "name", length = 255)
	private String name;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "userRole")
	@JsonIgnore
	private List<User> userList;

	public User_Roles() {
	}

	public Integer getUsers_iduser() {
		return users_iduser;
	}

	public void setUsers_iduser(Integer users_iduser) {
		this.users_iduser = users_iduser;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public List<User> getUserList() {
        return userList;
    }

    public void setUserList(List<User> userList) {
        this.userList = userList;
    }

	public User_Roles(Integer users_iduser, String name) {
		super();
		this.users_iduser = users_iduser;
		this.name = name;
	}
    
}
