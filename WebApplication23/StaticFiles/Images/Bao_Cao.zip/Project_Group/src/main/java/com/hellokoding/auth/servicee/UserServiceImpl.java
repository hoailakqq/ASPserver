package com.hellokoding.auth.servicee;

import com.hellokoding.auth.modell.User;
import com.hellokoding.auth.modell.User_Roles;
import com.hellokoding.auth.repositoryy.RoleRepository;
import com.hellokoding.auth.repositoryy.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private RoleRepository roleRepository;
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void save(User user) {
		User_Roles role = new User_Roles(1, "admin");
		user.setPass(bCryptPasswordEncoder.encode(user.getPass()));
//    	user.setPass(user.getPass());
		user.setUserRole(role);
		userRepository.save(user);
	}

	@Override
	public User findByUsername(String username) {
		return userRepository.findByUsername(username);
	}

	@Override
	public Optional<User> findUserByEmail(String email) {
		return userRepository.findByEmail(email);
	}

	@Override
	public List<User> findAll() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

	@Override
	@Transactional
	public void xoaUSTheoMaUS(int iduser) {
		userRepository.deleteById(iduser);
	}

	@Override
	public User layUserTheoMa(int id) {
		return userRepository.findById(id).get();
	}

	@Transactional
	@Override
	public void updateUser(User user, int role) {
		User_Roles userRole = roleRepository.findUserRole(role);
		user.setUserRole(userRole);
		System.out.println(user.getEmail() + user.getIduser());
		entityManager.createNativeQuery(
				"UPDATE User SET email = ?, ho_ten = ?, pass = ? , username = ?, users_iduser = ? WHERE iduser = ?")
				.setParameter(1, user.getEmail()).setParameter(2, user.getHoTen()).setParameter(3, user.getPass())
				.setParameter(4, user.getUsername()).setParameter(5, role).setParameter(6, user.getIduser())
				.executeUpdate();
	}

	@Override
	public Optional<User> findOne(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteById(int id) {
		userRepository.deleteById((int) id);

	}

	@Override
	public void deleteUser(int id) {
		userRepository.deleteById(id);

	}

	@Override
	public void deleteAll(List<User> entities) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteAll() {
		// TODO Auto-generated method stub

	}

	@Override
	public Optional<User> getfindByID(int id) {
		return userRepository.findById(id);
	}

	@Override
	public void saveUser(User user, int idRole) {
		User_Roles role = roleRepository.findUserRole(idRole);
		user.setUserRole(role);
		userRepository.save(user);
	}
}
