package com.hellokoding.auth.modell;

import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "product")
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "idproduct", nullable = false)
	private Integer idproduct;

//	@NotBlank(message = "Tên sản phẩm không được trống")
	@Column(name = "name", nullable = true, length = 255)
	private String name;

	@Column(name = "status")
	private boolean status;

//	@NotBlank(message = "Giá sản phẩm không được trống")
	@Column(name = "price", nullable = true, length = 255)
	private int price;

	@Column(name = "price_new", nullable = true, length = 255)
	private int price_new;

	@ManyToOne
	@JoinColumn(name = "idmenu")
	private Menu menu_product;

	@ManyToOne
	@JoinColumn(name = "idcategory")
	private Category category;

//	@NotBlank(message = "Hình ảnh sản phẩm không được trống")
	@Column(name = "img", nullable = true, length = 255)
	private String img;

	@Column(name = "date", nullable = true, length = 255)
	private Date date;

//	@NotBlank(message = "Số lượng nhập sản phẩm không được trống")
	@Column(name = "count", nullable = true, length = 255)
	private int count;

	@Column(name = "so_luong_con", nullable = true, length = 255)
	private int so_luong_con;

//		@NotBlank(message = "Mô tả sản phẩm sản phẩm không được trống")
	@Column(name = "description", nullable = true, length = 255)
	private String description;

//		@NotBlank(message = "Mô tả sản phẩm sản phẩm không được trống")
	@Column(name = "screen", nullable = true, length = 255)
	private String screen;
//		@NotBlank(message = "Mô tả sản phẩm sản phẩm không được trống")
	@Column(name = "operating_system", nullable = true, length = 255)
	private String operating_system;
//		@NotBlank(message = "Mô tả sản phẩm sản phẩm không được trống")
	@Column(name = "back_camera", nullable = true, length = 255)
	private String back_camera;
//		@NotBlank(message = "Mô tả sản phẩm sản phẩm không được trống")
	@Column(name = "front_camera", nullable = true, length = 255)
	private String front_camera;
//		@NotBlank(message = "Mô tả sản phẩm sản phẩm không được trống")
	@Column(name = "cpu", nullable = true, length = 255)
	private String cpu;
//		@NotBlank(message = "Mô tả sản phẩm sản phẩm không được trống")
	@Column(name = "ram", nullable = true, length = 255)
	private String ram;
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "product")
	@JsonIgnore
	private List<Comment>  commentList;
	public Integer getIdproduct() {
		return idproduct;
	}
	public void setIdproduct(Integer idproduct) {
		this.idproduct = idproduct;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getPrice_new() {
		return price_new;
	}
	
	public void setPrice_new(int price_new) {
		this.price_new = price_new;
	}
	public Menu getMenu_product() {
		return menu_product;
	}
	public void setMenu_product(Menu menu_product) {
		this.menu_product = menu_product;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public int getSo_luong_con() {
		return so_luong_con;
	}
	public void setSo_luong_con(int so_luong_con) {
		this.so_luong_con = so_luong_con;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getScreen() {
		return screen;
	}
	public void setScreen(String screen) {
		this.screen = screen;
	}
	public String getOperating_system() {
		return operating_system;
	}
	public void setOperating_system(String operating_system) {
		this.operating_system = operating_system;
	}
	public String getBack_camera() {
		return back_camera;
	}
	public void setBack_camera(String back_camera) {
		this.back_camera = back_camera;
	}
	public String getFront_camera() {
		return front_camera;
	}
	public void setFront_camera(String front_camera) {
		this.front_camera = front_camera;
	}
	public String getCpu() {
		return cpu;
	}
	public void setCpu(String cpu) {
		this.cpu = cpu;
	}
	public String getRam() {
		return ram;
	}
	public void setRam(String ram) {
		this.ram = ram;
	}
	
	

}
