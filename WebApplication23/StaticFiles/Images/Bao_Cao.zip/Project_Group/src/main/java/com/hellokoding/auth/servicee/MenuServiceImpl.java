package com.hellokoding.auth.servicee;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hellokoding.auth.modell.Menu;
import com.hellokoding.auth.repositoryy.MenuRepository;

@Service
public class MenuServiceImpl implements MenuService {
	@Autowired
	private MenuRepository menuRepository;

	@Override
	public List<Menu> findAll() {

		return menuRepository.findAll();
	}

	@Override
	public void deleteAll() {
		menuRepository.deleteAll();

	}

	@Override
	public void deleteById(int id) {
		menuRepository.deleteById((long) id);

	}

	@Override
	public Optional<Menu> getfindByID(int id) {
		// TODO Auto-generated method stub
		return menuRepository.findById((long) id);
	}

	@Override
	public void updateMenu(Menu menu) {

		menuRepository.save(menu);

	}

	@Override
	public void save(Menu menu) {
		menuRepository.save(menu);

	}

}
