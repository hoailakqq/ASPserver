package com.hellokoding.auth.servicee;

import java.util.List;

import com.hellokoding.auth.modell.User_Roles;

public interface User_RoleSerivce {
	List<User_Roles> findAll();
}
