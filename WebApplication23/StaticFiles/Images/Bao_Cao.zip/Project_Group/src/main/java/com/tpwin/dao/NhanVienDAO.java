//package com.tpwin.dao;
//
//import org.hibernate.Session;
//import org.hibernate.SessionFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.context.annotation.Scope;
//import org.springframework.context.annotation.ScopedProxyMode;
//import org.springframework.stereotype.Repository;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.hellokoding.auth.modell.User;
//import com.hellokoding.auth.repositoryy.NhanVienDAOImp;
//
//
//@Repository
//@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS)
//public class NhanVienDAO implements NhanVienDAOImp {
//	@Autowired
//	SessionFactory sessionFactory;
//
//	@Transactional
//	public boolean ktDangNhap(String email, String matkhau) {
//		Session session = sessionFactory.getCurrentSession();
//		try {
//			User nhanVien = (User) session
//					.createQuery("from user where username = '" + email + "' and pass = '" + matkhau + "'")
//					.getSingleResult();
//			if (nhanVien != null) {
//				return true;
//			} else {
//				return false;
//			}
//		} catch (Exception e) {
//			return false;
//		}
//
//	}
//
//	@Transactional
//	public boolean themNhanVien(User nhanVien) {
//		Session session = sessionFactory.getCurrentSession();
//		int manv = (Integer) session.save(nhanVien);
//
//		if (manv > 0) {
//			return true;
//		} else {
//
//			return false;
//		}
//	}
//
//	@Transactional
//	public boolean ktemail(String email) {
//		Session session = sessionFactory.getCurrentSession();
//		try {
//			User nhanVien = (User) session.createQuery("from user where username='" + email)
//					.getSingleResult();
//			if (nhanVien != null) {
//				return false;
//			} else {
//				return true;
//			}
//		} catch (Exception e) {
//			return true;
//		}
//
//	}
//
//}
