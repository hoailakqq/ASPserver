package com.hellokoding.auth.web;

import com.hellokoding.auth.modell.Product;
//import com.hellokoding.auth.modell.Shopping_Cart;
import com.hellokoding.auth.modell.User;
import com.hellokoding.auth.servicee.ProductService;
//import com.hellokoding.auth.servicee.NhanVienService;
import com.hellokoding.auth.servicee.SecurityService;
//import com.hellokoding.auth.servicee.ShoppingCartService;
import com.hellokoding.auth.servicee.UserService;
//import com.hellokoding.auth.validator.UserValidator;

import java.awt.Window;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

@Controller
public class UserController {
	@Autowired
	private UserService userService;

	@Autowired
	private SecurityService securityService;

	@Autowired
	private ProductService proService;

//	@Autowired
//	ShoppingCartService cartService;

	@GetMapping("/dangky")
	public String viewPersonList(Model model) {
		model.addAttribute("user", new User());
		System.out.println("111");
		return "signin";
	}

	@PostMapping("/dangky")
	public String dangKyForm(@Valid @ModelAttribute("user") User user, BindingResult bindingResult, Model model) {
//		userValidator.validate(user, bindingResult);
//		if (bindingResult.hasErrors()) {
//			System.out.println("Lỗi" + bindingResult.hasErrors());
//			return "signin";
//		} else {
//			User getuser = userService.findByUsername(user.getUsername());
//			if (getuser != null) {
//				return "dangnhap";
//			} else {
//				userService.save(user);
//			}
		return "signin";
//		}

	}

	@GetMapping("/dangnhap")
	public String viewPersonList2(Model model) {
		model.addAttribute("user", new User());
		System.out.println("2222");

		return "login";
	}

	@PostMapping("/dangnhap")
//	@ResponseBody
	public String login(@Valid @ModelAttribute("user") User user, BindingResult bindingResult, Model model) {

//		if (error != null)
//			model.addAttribute("error", "Your username and password is invalid.");
//		if (logout != null)
//			model.addAttribute("message", "You have been logged out successfully.");
//		if (bindingResult.hasErrors()) {
//			System.out.println("Lỗi"+bindingResult.hasErrors());
//			return "login";
//		} else {

//		System.out.println("postne");
//		if (userService.findByUsername(user.getUsername()) == null) {
//			return "login";
//		}
//		if (userService.findByUsername(user.getUsername()) != null) {
//			System.out.println(user.getUsername() + "111111" + user.getPass());
//			boolean kt = nvservice.ktDangNhap(user.getUsername(), user.getPass());

//			System.out.println(kt);
//			if (kt == true) {
//			System.out.println(kt);
//			return "redirect:/";
//			}
//		}
//		}
		return "login";

	}

	@PostMapping("/shoppingCart")
	public String viewShoppingCart(HttpSession session, HttpServletRequest request) {
		session = request.getSession();
		User htt = (User) session.getAttribute("userss");

		return "shoppingCart";
	}

	@PostMapping("/payment")
	public String viewPayment(HttpSession session, HttpServletRequest request) {
		session = request.getSession();
		User htt = (User) session.getAttribute("userss");

		return "payment";
	}

	@GetMapping("/payment")
	public String viewPayment(Model model) {
		model.addAttribute("user", new User());
		System.out.println("111");
		return "payment";
	}

	@GetMapping("/dialog")
	public String viewDialog(Model model) {
		model.addAttribute("user", new User());
		System.out.println("111");
		return "notifi";
	}
	@GetMapping("/footer")
	public String viewFooter(Model model) {
		model.addAttribute("user", new User());
		System.out.println("111");
		return "footer";
	}

}