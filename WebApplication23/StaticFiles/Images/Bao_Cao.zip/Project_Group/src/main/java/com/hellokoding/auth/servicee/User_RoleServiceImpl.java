package com.hellokoding.auth.servicee;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hellokoding.auth.modell.User_Roles;
import com.hellokoding.auth.repositoryy.RoleRepository;
@Service
public class User_RoleServiceImpl implements User_RoleSerivce{

	@Autowired
	RoleRepository user_RoleRepository;
	@Override
	public List<User_Roles> findAll() {
		// TODO Auto-generated method stub
		return user_RoleRepository.findAll();
	}

}
