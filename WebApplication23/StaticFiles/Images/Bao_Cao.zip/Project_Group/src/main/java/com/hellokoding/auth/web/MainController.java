package com.hellokoding.auth.web;

import java.util.List;
import java.util.Properties;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.hellokoding.auth.modell.Category;
import com.hellokoding.auth.modell.Menu;
import com.hellokoding.auth.modell.Product;
import com.hellokoding.auth.modell.Shopping_Cart;
import com.hellokoding.auth.modell.User;
import com.hellokoding.auth.modell.User_Roles;
import com.hellokoding.auth.servicee.CategoryService;
import com.hellokoding.auth.servicee.MenuService;
import com.hellokoding.auth.servicee.ProductServiceImpl;
import com.hellokoding.auth.servicee.ShoppingCartService;
import com.hellokoding.auth.servicee.UserService;

@Controller
public class MainController {
	@Autowired
	MenuService menuService;
	@Autowired
	UserService userService;
	@Autowired
	CategoryService categoryService;
	@Autowired
	ShoppingCartService cartService;
	@Autowired
	ProductServiceImpl sanphamDAO;

	@RequestMapping(value = { "/", "/index" }, method = RequestMethod.GET)
	public String welcomee(ModelMap model) {
		List<Menu> menus = menuService.findAll();
		model.addAttribute("menus", menus);
		for (int i = 0; i < menus.size(); i++) {
			List<Category> categorys = categoryService.findCategory(i);
			menus.get(i).setCategory(categorys);
			int mn = menus.get(i).getIdmenu();
			model.addAttribute("categorys" + i, categorys);
		}

		List<Product> products = sanphamDAO.dtNoiBat();
		model.addAttribute("products", products);
//			
		List<Product> laptop = sanphamDAO.ltNoiBat();
		model.addAttribute("laptops", laptop);
		List<Product> phukien = sanphamDAO.pkNoiBat();
		model.addAttribute("phukiens", phukien);

		List<Product> tablet = sanphamDAO.tbNoiBat();
		model.addAttribute("tablets", tablet);
		return "index";
	}

	@RequestMapping(value = { "/ktdangnhap" }, method = RequestMethod.POST)
	@ResponseBody
	public String loginControl(String userName, String pass, ModelMap map, HttpSession session) {
		User getuser = userService.findByUsername(userName);
		String kt = "-1";
		if (getuser != null && getuser.getPass().equals(pass)) {
			if (getuser.getUserRole().getUsers_iduser() == 1) {
				session.setAttribute("userss", getuser);
				kt = "1";
			}
			if (getuser.getUserRole().getUsers_iduser() == 0) {
				session.setAttribute("userss", getuser);
				kt = "0";
			}
		}
		return kt + "";

	}

	@GetMapping("/logout")
	public String viewPersonList(HttpSession session, HttpServletRequest request) {
		session = request.getSession();
		session.invalidate();
		// session.invalidate();
		return "index";

	}

	@GetMapping("/login")
	public String viewPersonListj(HttpSession session, HttpServletRequest request) {

		return "index";

	}

	@PersistenceContext
	private EntityManager entityManager;

	@Transactional
	public boolean insertWithQuery(User user) {
		entityManager.createNativeQuery(
				"INSERT INTO `tesst`.`user`(`email`, `ho_ten`, `pass`, `status`, `username`, `users_iduser`) VALUES (?, ?, ?, ?, ?, ?)")
				.setParameter(1, user.getEmail()).setParameter(2, user.getHoTen()).setParameter(3, user.getPass())
				.setParameter(4, true).setParameter(5, user.getUsername()).setParameter(6, new User_Roles(1, "normal"))
				.executeUpdate();

		return true;
	}

// api nhập username để trả

	@Transactional
	@RequestMapping(value = { "/ktdangky" }, method = RequestMethod.POST)
	@ResponseBody
	public boolean RegisterControl(String userName, String pass, String email, String fullName, ModelMap map) {

		User getuser = userService.findByUsername(userName);
		System.out.println(getuser);
//	String passCrypt = bCryptPasswordEncoder.encode(pass);
		User a = new User(userName, pass, email, fullName, new User_Roles(1, "normal"), true);
		System.out.println(a.getEmail());
		try {
			return (getuser == null) ? insertWithQuery(a) : false;
		} catch (Exception e) {
			// TODO: handle exception
			return false;
		}

	}

	// gio hang

	@Transactional
	public String updateShoppingCart(Shopping_Cart cart) {
		entityManager.createNativeQuery("UPDATE `tesst`.`shopping_cart` SET `value` = ? WHERE `userkh` = ?")
				.setParameter(1, cart.getValue()).setParameter(2, cart.getUserKH()).executeUpdate();
		return "update";
	}

	@Transactional
	public String insertShoppingCart(Shopping_Cart cart) {

		entityManager.createNativeQuery("INSERT INTO `tesst`.`shopping_cart`(`userkh`, `value`) VALUES (?, ?)")
				.setParameter(1, cart.getUserKH()).setParameter(2, cart.getValue()).executeUpdate();
		entityManager.createNativeQuery("UPDATE `cdw1`.`shopping_cart` SET `value` = ? WHERE `userkh` = ?")
				.setParameter(1, cart.getValue()).setParameter(2, cart.getUserKH()).executeUpdate();
		return "insert";
	}

	@Transactional
	@RequestMapping(value = { "/giohang" }, method = RequestMethod.POST)
	@ResponseBody
	public String shoppingCartProduct(String value, String userKH, ModelMap map) {

		Shopping_Cart shcart = cartService.findByUserKH(userKH);
		if (value != "") {
			Shopping_Cart carts = new Shopping_Cart(userKH, value);
			return (shcart == null) ? insertShoppingCart(carts) : updateShoppingCart(carts);
		} else
			return "";

	}

	@Transactional
	@RequestMapping(value = { "/getgiohang" }, method = RequestMethod.POST)
	@ResponseBody
	public String getshoppingCartProduct(String userKH, ModelMap map) {

		Shopping_Cart shcart = cartService.findByUserKH(userKH);

		return (shcart == null) ? "" : shcart.getValue();

	}

	@Bean
	public JavaMailSender getJavaMailSender() {
		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
		mailSender.setHost("smtp.gmail.com");
		mailSender.setPort(587);

		mailSender.setUsername("ruangocxx@gmail.com");
		mailSender.setPassword("GiangHuou");

		Properties props = mailSender.getJavaMailProperties();
		props.put("mail.transport.protocol", "smtp");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.debug", "true");

		return mailSender;
	}

	@Autowired
	public JavaMailSender emailSender;

	@ResponseBody
	@RequestMapping(value = { "/sendEmail" }, method = RequestMethod.POST)
	public Boolean sendSimpleEmail(String email) throws MessagingException {
		User getuser = userService.findByUsername(email);

		if (getuser != null) {

			MimeMessage message = emailSender.createMimeMessage();

			boolean multipart = true;

			MimeMessageHelper helper = new MimeMessageHelper(message, multipart, "utf-8");

			String htmlMsg = "<h3>Password is :</h3>" + "<span style ='color : red'>" + getuser.getPass()
					+ "<img width='200px' height='200px' src='https://tieuthao.files.wordpress.com/2011/12/hccts.gif'>";

			message.setContent(htmlMsg, "text/html");

			helper.setTo(getuser.getEmail());

			helper.setSubject("Test send HTML email");

			this.emailSender.send(message);

			return true;
		} else {
			return false;
		}
	}

}
