package com.hellokoding.auth.modell;

import java.util.List;

import javax.persistence.*;
import javax.persistence.criteria.CriteriaBuilder.In;
import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "category")
public class Category {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "idcategory", nullable = false)
	private Integer idcategory;

	@NotBlank(message = "Tên danh mục không được trống")
	@Column(name = "name", nullable = false, length = 255)
	private String name;

	@Column(name = "status")
	private boolean status;

	@ManyToOne
	@JoinColumn(name = "idmenu")
	private Menu menu;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "category")
	@JsonIgnore
	private List<Product> product;

	public Integer getIdcategory() {
		return idcategory;
	}

	public void setIdcategory(Integer idcategory) {
		this.idcategory = idcategory;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public Menu getMenu() {
		return menu;
	}

	public void setMenu(Menu menu) {
		this.menu = menu;
	}
	
	public Category() {
		// TODO Auto-generated constructor stub
	}
//		@Transient
//		private String passwordConfirm;

}
