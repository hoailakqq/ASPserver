package com.hellokoding.auth.servicee;

import java.util.List;
import java.util.Optional;

import com.hellokoding.auth.modell.User;

public interface UserService {
	void save(User user);

	List<User> findAll();

	User findByUsername(String username);

	public Optional<User> findUserByEmail(String email);

	User layUserTheoMa(int id);

	void xoaUSTheoMaUS(int iduser);

	Optional<User> findOne(long id);

	void deleteUser(int id);

	void deleteById(int id);

	void deleteAll(List<User> entities);

	void deleteAll();

	void updateUser(User user, int role);

	Optional<User> getfindByID(int id);
    void saveUser(User user,int idRole);


}
