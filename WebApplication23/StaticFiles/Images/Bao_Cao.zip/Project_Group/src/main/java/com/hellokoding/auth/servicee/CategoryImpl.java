package com.hellokoding.auth.servicee;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.jpa.repository.Query;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.hellokoding.auth.modell.Category;
import com.hellokoding.auth.modell.Menu;
import com.hellokoding.auth.repositoryy.CategoryRepository;

@Service
public class CategoryImpl implements CategoryService {
//	@Autowired
//	private CategoryRepository category;

//	@Autowired
//	private EntityManager entityManager;
	@Autowired
	private CategoryRepository categoryRepository;

	@Override
	public List<Category> findAll() {
		return categoryRepository.findAll();
	}

	@Override
	public List<Category> findCategory(int id) {
//			String sql = "select c from Category c where c.idcategory = "+id;
//			javax.persistence.Query query = entityManager.createQuery(sql);
//			return (List<Category>) query.getSingleResult();
//		return category.findAll();
		return categoryRepository.lstCategory(id);
//		return categoryRepository.findAllById(id);
	}
	@Override
	public Category find(int id) {
		return categoryRepository.findById(id).get();
	}

	@Override
	public void deleteAll() {
		categoryRepository.deleteAll();
		
	}

	@Override
	public void deleteById(int id) {
		categoryRepository.deleteById(id);
		
	}

	@Override
	public void updateCate(Category category) {
		Menu menu = new Menu(1);
		category.setMenu(menu);
		categoryRepository.save(category);
		
	}

	@Override
	public Optional<Category> getfindByID(int id) {
		// TODO Auto-generated method stub
		return categoryRepository.findById(id);
	}


}
