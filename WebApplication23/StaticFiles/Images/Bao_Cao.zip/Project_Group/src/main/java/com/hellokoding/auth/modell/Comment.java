package com.hellokoding.auth.modell;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "comment")
public class Comment {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "idcomment", nullable = false)
	private Integer idcomment;
	@Column(name = "comments")
	private String comments;
	@Column(name = "answer")
	private String answer;
	@Column(name = "date")
	private Date date;
	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	@ManyToOne
	@JoinColumn(name = "iduser")
	private User user;
	@ManyToOne
	@JoinColumn(name = "idproduct")
	private Product product;
	
	public Integer getIdcomment() {
		return idcomment;
	}
	public void setIdcomment(Integer idcomment) {
		this.idcomment = idcomment;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	

}
