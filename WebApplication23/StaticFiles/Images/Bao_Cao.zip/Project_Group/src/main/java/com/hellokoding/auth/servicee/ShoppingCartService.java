package com.hellokoding.auth.servicee;

import com.hellokoding.auth.modell.Shopping_Cart;

public interface ShoppingCartService {
	void save(Shopping_Cart cart);

	Shopping_Cart findByUserKH(String userKH);

}
