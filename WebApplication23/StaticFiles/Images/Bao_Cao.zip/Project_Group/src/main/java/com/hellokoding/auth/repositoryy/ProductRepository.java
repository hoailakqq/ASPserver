package com.hellokoding.auth.repositoryy;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.hellokoding.auth.modell.Category;
import com.hellokoding.auth.modell.Menu;
import com.hellokoding.auth.modell.Product;

public interface ProductRepository extends JpaRepository<Product, Integer> {
	@Query(value = "SELECT p FROM Product p WHERE p.idproduct = ?1")
	Product findByProductId(int id);
	@Query(value = "select p from Product p where status = 1  and idcategory = ?1")
	List<Product> layDSSPTheoDM(int idcategory);
	@Query(value ="SELECT m FROM Menu m WHERE m.idmenu = ?1")
	Menu findMenuById(int idmenu);
	@Query(value ="SELECT c FROM Category c WHERE c.idcategory  = ?1")
	Category findCategoryById(int idcategory);
}
