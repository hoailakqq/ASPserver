package com.hellokoding.auth.modell;

import java.util.List;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;

import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "menu")
public class Menu {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "idmenu", nullable = false)
	private Integer idmenu;
	
	@NotBlank(message = "Tên menu không được trống")
	@Column(name = "name", nullable = false)
	private String name;
	
	@Column(name = "isActive", nullable = false)
	private boolean isActive;
	
	
	@Column(name = "href", nullable = false)
	private String href;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "menu")
	@JsonIgnore
//	@Autowired(required = false)
	private List<Category> category;
	
	
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "menu_product")
	@JsonIgnore
	private List<Product> product;
	
	public Menu(int i) {
		// TODO Auto-generated constructor stub
	}

	public Menu() {
		super();
	}

	public Integer getIdmenu() {
		return idmenu;
	}

	public void setIdmenu(Integer idmenu) {
		this.idmenu = idmenu;
	}

	public List<Category> getCategory() {
		return category;
	}

	public List<Category> setCategory(List<Category> category) {
		return this.category = category;
	}

	public Integer getIduser() {
		return idmenu;
	}

	public void setIduser(Integer iduser) {
		this.idmenu = iduser;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public String getHref() {
		return href;
	}

	public void setHref(String href) {
		this.href = href;
	}
//	<c:out>
//	int idmenu=${menu.getId() };
//		CategoryService categoryService;
//			List<Category> lst = categoryService.findCategory();
//			for (int j = 0; j < lst.size(); j++) {
//				System.out.println("log: " + lst.get(j).toString());
//			}
//	</c:out>
	
//	<c:forEach var="menu" items="${menus }">
//	<li class="dropdown mega-dropdown active"><a
//		href="${menu.getHref() }" class="dropdown-toggle"
//		data-toggle="dropdown">${menu.getName() }<span class="caret"></span></a>
//		<div
//			class="dropdown-menu mega-dropdown-menu w3ls_vegetables_menu">
//			<div class="w3ls_vegetables">
//				<ul>
//					<c:forEach var="category" items="${category }">
//						<li><a href="#">${category.getName() }</a></li>
//					</c:forEach>
//				</ul>
//			</div>
//		</div></li>
//
//</c:forEach>
}
