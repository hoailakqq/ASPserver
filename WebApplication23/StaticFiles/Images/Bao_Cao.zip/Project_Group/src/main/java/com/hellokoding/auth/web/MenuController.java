package com.hellokoding.auth.web;

import java.util.List;

import javax.persistence.EntityManager;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.hellokoding.auth.modell.Category;
import com.hellokoding.auth.modell.Menu;
import com.hellokoding.auth.modell.User;
import com.hellokoding.auth.servicee.CategoryService;
import com.hellokoding.auth.servicee.MenuService;

@Controller
public class MenuController {
	
	@Autowired
	MenuService menuService;
	@Autowired
	CategoryService categoryService;
	
	
	@GetMapping("/quanMenu")
	public String ListMenu(Model model) {
		List<Menu> menus = menuService.findAll();
		for (int i = 0; i < menus.size(); i++) {
			model.addAttribute("menu", menus);
			System.out.println(menus.size());
		}
		
		return "quanly_menu";
	}
	
	@RequestMapping(value = "/delete_Menu" , method = RequestMethod.GET)
	public String xoaMenu(@RequestParam int idmenu , RedirectAttributes redirect, Model model){
		menuService.deleteById(idmenu);
		model.addAttribute("menu", menuService.findAll());
		return "redirect:/quanMenu";
	}
	
	
	@RequestMapping(value = "/delete_Menu" , method = RequestMethod.POST)
	@ResponseBody
	public String xoa(ModelMap model, @Valid Menu menu, RedirectAttributes redirect){
		return "quanly_menu";
	}
	@RequestMapping(value = "update_Menu" , method = RequestMethod.GET)
	public String showUpdate(@RequestParam int idmenu , ModelMap model) {
		model.put("category", categoryService.findAll());
		Menu menu = menuService.getfindByID(idmenu).get();
		model.put("menu", menu);
		return "sua_menu";
	}
	@RequestMapping(value = "update_Menu" , method = RequestMethod.POST)
	public String updateUser(ModelMap model, @Valid  Menu menu, BindingResult result,RedirectAttributes redirect) {
		
		if(result.hasErrors()) {
			return "sua_menu";
		}
		
	
		menuService.updateMenu(menu);
		
		return "redirect:/quanMenu";
	}
}
