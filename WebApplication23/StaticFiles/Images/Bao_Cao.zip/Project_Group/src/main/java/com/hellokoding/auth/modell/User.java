package com.hellokoding.auth.modell;

import javax.persistence.*;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.List;
import java.util.Set;

@Entity
@Table(name = "user")
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "iduser", nullable = false)
	private Integer iduser;

	@Size(min = 6, message = "Mật khẩu chỉ được nhập từ 6 đến 8 kí tự")
	@NotBlank(message = "Mật khẩu không được trống")
	@Column(name = "pass", nullable = false, length = 255)
	private String pass;

	@NotBlank(message = "Username không được trống")
	@Size(max = 10, min = 5, message = "Chỉ được nhập từ 5 đến 10 kí tự")
	@Column(name = "username", nullable = false, length = 255)
	private String username;

	@Column(name = "email", nullable = false, length = 255)
	@NotBlank(message = "Email không được trống")
	@Email(message = "Sai định dạng địa chỉ Email")
	private String email;

	@Column(name = "hoTen", nullable = false, length = 255)
	@NotBlank(message = "Họ tên không được trống")
	private String hoTen;

	@ManyToOne
	@JoinColumn(name = "users_iduser")
	private User_Roles userRole;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "user")
	@JsonIgnore
	private List<Comment>  commentList;

//	@Transient
//	private String passwordConfirm;

	private boolean status;

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}

	public Integer getIduser() {
		return iduser;
	}

	public void setIduser(Integer iduser) {
		this.iduser = iduser;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getHoTen() {
		return hoTen;
	}

	public void setHoTen(String hoTen) {
		this.hoTen = hoTen;
	}

	public User_Roles getUserRole() {
		return userRole;
	}

	public void setUserRole(User_Roles userRole) {
		this.userRole = userRole;
	}

//	public String getPasswordConfirm() {
//		return passwordConfirm;
//	}
//
//	public void setPasswordConfirm(String passwordConfirm) {
//		this.passwordConfirm = passwordConfirm;
//	}
	public User() {
		// TODO Auto-generated constructor stub
	}

	public User(String userName, String pass, String email, String hoTen, User_Roles user_Roles, boolean status) {
		// TODO Auto-generated constructor stub
		this.username = userName;
		this.pass = pass;
		this.email = email;
		this.hoTen = hoTen;
		this.userRole = user_Roles;
		this.status = status;
	}

//	<form:form modelAttribute="user">
//	<form:input path="username" name="Username" placeholder="Username"
//		required=" " />
//	<form:input type="password" name="Password"
//		placeholder="Password" required=" " path="pass" />
//	<form:button>Đăng nhập</form:button>
//</form:form>

}
